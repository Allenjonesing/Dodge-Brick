﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;
using Photon.Pun;

public class ContinuousMovement : MonoBehaviour
{
    public float speed = 1;
    public XRNode inputSource;
    public float gravity = -9.81f;
    public LayerMask groundLayer;
    public float additionalHeight = 0.2f;

    private float fallingSpeed;
    private XRRig rig;
    private Vector2 inputAxis;
    private PhotonView photonView;

    // Start is called before the first frame update
    void Start()
    {
        rig = FindObjectOfType<XRRig>();
        photonView = GetComponent<PhotonView>();
    }

    // Update is called once per frame
    void Update()
    {
        InputDevice device = InputDevices.GetDeviceAtXRNode(inputSource);
        device.TryGetFeatureValue(CommonUsages.primary2DAxis, out inputAxis);
    }

    // Movement is applied locally on the owner's client only.
    // Photon's PhotonTransformView (observed by the PhotonView on this object)
    // syncs the resulting position to all other clients automatically.
    private void FixedUpdate()
    {
        if (photonView.IsMine)
        {
            Quaternion headYaw = Quaternion.Euler(0, rig.cameraGameObject.transform.eulerAngles.y, 0);
            Vector3 direction = headYaw * new Vector3(inputAxis.x, 0, inputAxis.y);

            // Move our position a step closer to the target.
            float step = speed * Time.fixedDeltaTime; // calculate distance to move
            var nextLocation = rig.transform.position + (direction / 2);

            if (!Physics.CheckSphere(new Vector3(nextLocation.x, 0, nextLocation.z), 0.1f, 1 << 12))
            {
                rig.transform.position = Vector3.MoveTowards(rig.transform.position, nextLocation, step);
            }
        }
    }
}
